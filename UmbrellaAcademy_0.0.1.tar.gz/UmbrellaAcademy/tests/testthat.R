library(testthat)
library(UmbrellaAcademy)

test_check("UmbrellaAcademy")
